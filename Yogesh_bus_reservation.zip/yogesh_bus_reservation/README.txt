yogesh BUS RESERVATION WEBSITE

HOW TO RUN
1. Extract the ZIP file.
2. Open the yogesh_bus_reservation folder.
3. Double-click index.html, or open it in Chrome/Edge.
4. Add passengers and buses, then create bookings.

FEATURES
- Dashboard overview and recent bookings
- Passenger records: Passenger ID, name, email, phone and password
- Bus records: Bus ID, bus number, pickup, destination, total seats and available seats
- Booking records: Booking ID, passenger ID, bus ID, date, seat, fare and status
- Add, edit, delete and search records
- Seat availability and duplicate seat checks
- Responsive navy/orange professional design
- Data saved in browser localStorage

NOTE
This is a front-end demo. Data is stored in the current browser only. Passwords are masked in the table but this demo does not provide production-grade authentication or secure server-side storage. The hero photo is loaded from Unsplash and needs internet access.
